#include "SDB.h"
#include <stdio.h>

void SDB_APP() {
    uint8 choice;
    while (1) {
        printf("\nMenu:\n");
        printf("1. To add entry, enter 1\n");
        printf("2. To get used size in database, enter 2\n");
        printf("3. To read student data, enter 3\n");
        printf("4. To get the list of all student IDs, enter 4\n");
        printf("5. To check if ID exists, enter 5\n");
        printf("6. To delete student data, enter 6\n");
        printf("7. To check if database is full, enter 7\n");
        printf("8. To exit, enter 0\n");
        printf("Your choice: ");
        scanf("%hhu", &choice);
        SDB_action(choice);
    }
}

void SDB_action(uint8 choice) {
    uint32 id, year, c1_id, c1_grade, c2_id, c2_grade, c3_id, c3_grade;
    uint8 count;
    uint32 list[MAX_STUDENTS];

    switch (choice) {
        case 1:
            printf("Enter student ID, year, Course1_ID, Course1_grade, Course2_ID, Course2_grade, Course3_ID, Course3_grade: ");
            scanf("%u %u %u %u %u %u %u %u", &id, &year, &c1_id, &c1_grade, &c2_id, &c2_grade, &c3_id, &c3_grade);
            if (SDB_AddEntry(id, year, c1_id, c1_grade, c2_id, c2_grade, c3_id, c3_grade)) {
                printf("Entry added successfully.\n");
            } else {
                printf("Failed to add entry. Database may be full.\n");
            }
            break;
        case 2:
            printf("Used size: %hhu\n", SDB_GetUsedSize());
            break;
        case 3:
            printf("Enter student ID to read: ");
            scanf("%u", &id);
            if (!SDB_ReadEntry(id)) {
                printf("Student not found.\n");
            }
            break;
        case 4:
            SDB_GetList(&count, list);
            printf("List of student IDs: ");
            for (uint8 i = 0; i < count; i++) {
                printf("%u ", list[i]);
            }
            printf("\n");
            break;
        case 5:
            printf("Enter student ID to check: ");
            scanf("%u", &id);
            if (SDB_IsIdExist(id)) {
                printf("ID exists.\n");
            } else {
                printf("ID does not exist.\n");
            }
            break;
        case 6:
            printf("Enter student ID to delete: ");
            scanf("%u", &id);
            SDB_DeleteEntry(id);
            printf("Entry deleted if it existed.\n");
            break;
        case 7:
            if (SDB_IsFull()) {
                printf("Database is full.\n");
            } else {
                printf("Database is not full.\n");
            }
            break;
        case 0:
            printf("Exiting...\n");
            return;
        default:
            printf("Invalid choice.\n");
            break;
    }
}
